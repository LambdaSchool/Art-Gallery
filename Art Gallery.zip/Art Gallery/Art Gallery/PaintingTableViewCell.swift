import UIKit

class PaintingTableViewCell: UITableView {
    
    let model = PaintingModel()

    @IBOutlet weak var portraitView: UIImageView!
    
    
    @IBOutlet weak var likeButton: UIButton!
    
    weak var paintingViewCellDelegate: PaintingTableViewCellDelegate?
    
    
    @IBAction func toggledAppreciation(_ sender: Any) {
        model.tappedLikeButton(on: self)
    }
    
    
    
    
    
    
}
