
import UIKit

class PaintingViewController: UIViewController {

    
    
    @IBOutlet weak var tableView: PaintingTableViewCell!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
}

